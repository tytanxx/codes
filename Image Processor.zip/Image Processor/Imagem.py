#Alunos: Diogo Nápolis, João Augusto, Julia Castro
#Classe Imagem - responsavel por criar o objeto imagem

class Imagem:
    #Construtor
    def __init__(self):
        self.imagem = None

    #setImagem
    def setImagem(self, imagem):
        self.imagem = imagem

    #getImagem
    def getImagem(self):
        return self.imagem