#Alunos: Diogo Nápolis, João Augusto, Julia Castro
#Classe App - responsavel por iniciar o programa

#Bibliotecas utilizadas
from GUI import GUI

if __name__ == "__main__":
    gui = GUI()