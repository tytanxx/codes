#Alunos: Diogo Nápolis, João Augusto, Julia Castro
#Classe Transformacao - responsavel por aplicar filtros e transformações

#Bibliotecas utilizadas
import cv2
from PIL import Image, ImageTk

class Transformacao:
    #Construtor
    def __init__(self, imagem, label_imagem):
        self.imagem = imagem
        self.label_imagem = label_imagem

    #Método para transformar a imagem em cinza
    def transformacao_cinza(self):
        #Aplica a transformação
        imagem_cinza = cv2.cvtColor(self.imagem, cv2.COLOR_BGR2GRAY)
        # Redimensiona a imagem cinza para ter as mesmas dimensões que a imagem original
        imagem_cinza = cv2.resize(imagem_cinza, (self.imagem.shape[1], self.imagem.shape[0]))
        # Garante que ambas as imagens tenham o mesmo número de canais
        imagem_cinza = cv2.cvtColor(imagem_cinza, cv2.COLOR_GRAY2BGR)
        #Salva a imagem modificada
        cv2.imwrite("filtro-cinza.png", imagem_cinza)
        self.exibir_imagem(imagem_cinza)

    #Método para transformar a imagem em bw
    def transformacao_bw(self):
        #Aplica a transformação
        imagem_cinza = cv2.cvtColor(self.imagem, cv2.COLOR_BGR2GRAY)
        # Redimensiona a imagem cinza para ter as mesmas dimensões que a imagem original
        imagem_cinza = cv2.resize(imagem_cinza, (self.imagem.shape[1], self.imagem.shape[0]))
        # Garante que ambas as imagens tenham o mesmo número de canais
        imagem_cinza = cv2.cvtColor(imagem_cinza, cv2.COLOR_GRAY2BGR)
        (thresh, imagem_black_white) = cv2.threshold(imagem_cinza, 127, 255, cv2.THRESH_BINARY)
        # Redimensiona a imagem cinza para ter as mesmas dimensões que a imagem original
        imagem_black_white = cv2.resize(imagem_black_white, (self.imagem.shape[1], self.imagem.shape[0]))
        # Garante que ambas as imagens tenham o mesmo número de canais
        #Salva a imagem modificada
        cv2.imwrite("filtro-bw.png", imagem_black_white)
        self.exibir_imagem(imagem_black_white)

    #Método para aplicar o filtro para embaçar a imagem
    def transformacao_embaçado(self):
        #Aplica o filtro
        imagem_embaçada = cv2.blur(self.imagem, ksize=(21, 21))
        #Salva a imagem modificada
        cv2.imwrite("filtro-embaçado.png", imagem_embaçada)
        self.exibir_imagem(imagem_embaçada)

    #Método para aplicar o filtro para inverter a imagem
    def transformacao_invertido(self):
        #Aplica o filtro
        imagem_invertida = cv2.bitwise_not(self.imagem)
        #Salva a imagem modificada
        cv2.imwrite("filtro-invertido.png", imagem_invertida)
        self.exibir_imagem(imagem_invertida)

    def exibir_imagem(self, imagem):
        # Concatenar imagens verticalmente
        im = cv2.hconcat([self.imagem, imagem])
        # Converter para RGB
        imagem_rgb = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
        # Converter para ImageTk
        img = Image.fromarray(imagem_rgb)
        imgtk = ImageTk.PhotoImage(image=img)
        # Atualizar a label com a imagem concatenada
        self.label_imagem.config(image=imgtk)
        self.label_imagem.image = imgtk