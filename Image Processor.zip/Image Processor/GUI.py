#Alunos: Diogo Nápolis, João Augusto, Julia Castro
#Classe GUI - responsavel por criar a janela, botões e a interação com o usuário

#Bibliotecas utilizadas
import cv2
from tkinter import Tk, Frame, Button, Label, filedialog, StringVar
from Imagem import Imagem
from Transformação import Transformacao
from Histograma import Histograma

class GUI:
    #Construtor
    def __init__(self):
        self.janela()

    #Método para criar a janela
    def janela(self):
        #Criação da janela
        janela = Tk()
        
        #Tamanho da janela
        janela.geometry('1700x800')
        
        #Título da janela
        janela.title("Processamento de Imagem")

        #Criar o componente Frame
        frame = Frame(janela)
        frame.grid(column=0, row=0, padx=15, pady=15)
        global label_imagem
        label_imagem = Label(frame)
        label_imagem.grid(row=1, columnspan=5)

        #Criar uma instância da classe Imagem
        imagem_obj = Imagem()

        #Variável de controle que será usada para rastrear o botão pressionado
        self.botao_clicado = StringVar()
        self.botao_clicado.set("")

        #Criação dos botões na janela com suas respectivas funções associadas
        self.criar_botao(frame, "Escolher Arquivo", 0, lambda: self.selecionar_arquivo(imagem_obj))
        self.criar_botao(frame, "Cinza", 1, lambda: self.botao_pressionado(imagem_obj, "Cinza"))
        self.criar_botao(frame, "Black White", 2, lambda: self.botao_pressionado(imagem_obj, "Black White"))
        self.criar_botao(frame, "Embaçado", 3, lambda: self.botao_pressionado(imagem_obj, "Embaçado"))
        self.criar_botao(frame, "Invertido", 4, lambda: self.botao_pressionado(imagem_obj, "Invertido"))
        self.criar_botao(frame, "Mostrar Histograma", 5, lambda: self.botao_pressionado(imagem_obj, "Mostrar Histograma"))

        #Loop para manter a janela aberta
        while True:
            if self.botao_clicado.get():
                self.botao_clicado.set("")
            #Loop
            janela.update()

    #Método para criar os botões
    def criar_botao(self, frame, texto, coluna, funcao):
        btn = Button(frame, text=texto, command=funcao)
        btn.grid(column=coluna, row=0, padx=25, pady=10, sticky="n")

    #Método para selecionar a imagem escolhida pelo usuário
    def selecionar_arquivo(self, imagem_obj):
        #Busca da imagem
        filename = filedialog.askopenfilename(initialdir="/", title="Select a File", filetypes=[("Imagens", "*.png;*.jpg")])
        imagem = cv2.imread(filename)

        #Tratamento da imagem para ela não ficar desproporcional na janela
        height, width = imagem.shape[:2]
        imagem_redimensionada = cv2.resize(imagem, (int(width * 0.3), int(height * 0.3)))

        #Atualiza a instância da classe Imagem
        imagem_obj.setImagem(imagem_redimensionada)
    
    #Método que verifica qual botão foi pressionado e executa sua função
    def botao_pressionado(self, imagem_obj, acao):
        transformacao = Transformacao(imagem_obj.getImagem(), label_imagem)
        if acao == "Cinza":
            transformacao.transformacao_cinza()
        elif acao == "Black White":
            transformacao.transformacao_bw()
        elif acao == "Embaçado":
            transformacao.transformacao_embaçado()
        elif acao == "Invertido":
            transformacao.transformacao_invertido()
        elif acao == "Mostrar Histograma":
            histograma = Histograma(imagem_obj.getImagem())
            histograma.mostrar_histograma()