#Alunos: Diogo Nápolis, João Augusto, Julia Castro
#Classe Histograma - responsavel por criar o histograma (tons de cinza) da imagem

#Bibliotecas utilizadas
import cv2
import matplotlib.pyplot as plt

class Histograma:
    #Construtor
    def __init__(self, imagem):
        self.imagem = imagem

    #Método para ciar e mostrar o histograma
    def mostrar_histograma(self):
        histograma = cv2.calcHist([self.imagem], [0], None, [256], [0, 256])
        plt.plot(histograma)
        plt.show()